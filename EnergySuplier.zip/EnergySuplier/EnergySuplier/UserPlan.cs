﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnergySuplier
{
    public class UserPlan
    {
        public string SupplierName { get; set; }
        
        public string PlanName { get; set; }
        
        public double TotalCost { get; set; }
       
    }
}
