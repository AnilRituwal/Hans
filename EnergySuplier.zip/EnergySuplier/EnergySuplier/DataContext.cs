﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EnergySuplier
{
    public static class DataContext
    {

        public static List<Plan> LoadDataSet(string jsonFilePath)
        {
            List<Plan> Plans;
            string currentDirectory = Directory.GetCurrentDirectory();
            string path = "Data";
            string fullPath = Path.Combine(currentDirectory, path, "plans.json");
            try
            {
                using (StreamReader r = new StreamReader(fullPath))
                {
                    string json = r.ReadToEnd();
                    Plans = JsonConvert.DeserializeObject<List<Plan>>(json);
                    return Plans;


                }
            }
            catch(FileNotFoundException ex)
            {
                throw new Exception("There is no file exist with supplied file path");
            }
           
        }
    }
}
