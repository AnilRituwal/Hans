﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnergySuplier
{
    public interface IEnergyService
    {
        public List<Plan> LoadPlans(string filepath);
        public List<UserPlan> GetPlans(int AnnualCost);
    }
}
