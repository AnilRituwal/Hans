﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnergySuplier
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string filepath= Console.ReadLine();
            IEnergyService _energyservice = new EnergyService(filepath.Replace("input","").Trim());
            while (true)
            {
                StringBuilder Planbuilder = new StringBuilder();
                string inpute = Console.ReadLine().Replace("annual_cost", "").Trim();
                if (inpute.Equals("exit"))
                    break;
                else
                {
                    List<UserPlan> UserplanList = _energyservice.GetPlans(Convert.ToInt32(inpute));
                    foreach (UserPlan plan in UserplanList)
                    {
                        Planbuilder.AppendLine(plan.SupplierName + "," + plan.PlanName + "," + plan.TotalCost);
                    }
                    Console.WriteLine(Planbuilder.ToString());
                }
            }
        }
    }
}
