﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EnergySuplier
{
    public class Plan
    {
        public string supplier_name { get; set; }
        public string plan_name { get; set; }
        public List<Price> prices { get; set; }
        public int? standing_charge { get; set; }
    }

    public class Price
    {
        public double rate { get; set; }
        public int threshold { get; set; }
    }
}
