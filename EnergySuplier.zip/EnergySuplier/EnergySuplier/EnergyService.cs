﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EnergySuplier
{
    public class EnergyService : IEnergyService
    {
        List<Plan> Plans;
        const double VAT = 5.0;
        public EnergyService(string filepath)
        {
            if(Plans==null)
            {
                Plans=DataContext.LoadDataSet(filepath);
            }
        }
        public List<UserPlan> GetPlans(int AnnualCost)
        {
            List<UserPlan> UserPlanList = new List<UserPlan>();
            if (Plans!= null && Plans.Count >0)
            {
                foreach (Plan plan in Plans)
                {
                    
                    double Plan_Annual_Cost = 0;
                    double ConsumptionostIncludingVat = 0;
                    int eneryConsuption = AnnualCost;
                    foreach (Price price in plan.prices)
                    {
                        if (price.threshold != 0)
                        {
                            Plan_Annual_Cost += price.threshold * price.rate;
                            eneryConsuption = eneryConsuption - price.threshold;
                        }
                        else
                        {
                            Plan_Annual_Cost += eneryConsuption * price.rate;
                        }
                    }
                    Plan_Annual_Cost = Plan_Annual_Cost / 100;
                    ConsumptionostIncludingVat = Plan_Annual_Cost + (Plan_Annual_Cost * VAT/ 100);
                    UserPlanList.Add( new UserPlan() { SupplierName = plan.supplier_name, PlanName = plan.plan_name, TotalCost = Math.Round(ConsumptionostIncludingVat, 2) });
                }
            }

            return UserPlanList.OrderBy(x=>x.TotalCost).ToList<UserPlan>();



        }
        /// <summary>
        /// this method can be used if there will be multiple Json data source file and user going to supply different file name everytime.
        /// </summary>
        /// <param name="filepath"></param>
        /// <returns></returns>
        public List<Plan> LoadPlans(string filepath)
        {
           
            return DataContext.LoadDataSet(filepath);
            
        }
    }
}
